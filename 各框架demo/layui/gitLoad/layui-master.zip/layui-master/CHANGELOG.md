
# 更新日志
* [2.1.6](http://www.layui.com/doc/base/changelog.html#2-1-6)
* [2.1.5](http://www.layui.com/doc/base/changelog.html#2-1-5)
* [2.1.4](http://www.layui.com/doc/base/changelog.html#2-1-4)
* [2.1.3](http://www.layui.com/doc/base/changelog.html#2-1-3)
* [2.1.2](http://www.layui.com/doc/base/changelog.html#2-1-2)
* [2.1.1](http://www.layui.com/doc/base/changelog.html#2-1-1)
* [2.1.0](http://www.layui.com/doc/base/changelog.html#2-1-0)
* [2.0.2](http://www.layui.com/doc/base/changelog.html#2-0-2)
* [2.0.1](http://www.layui.com/doc/base/changelog.html#2-0-1)
* [2.0.0](http://www.layui.com/doc/base/changelog.html#2-0-0)
