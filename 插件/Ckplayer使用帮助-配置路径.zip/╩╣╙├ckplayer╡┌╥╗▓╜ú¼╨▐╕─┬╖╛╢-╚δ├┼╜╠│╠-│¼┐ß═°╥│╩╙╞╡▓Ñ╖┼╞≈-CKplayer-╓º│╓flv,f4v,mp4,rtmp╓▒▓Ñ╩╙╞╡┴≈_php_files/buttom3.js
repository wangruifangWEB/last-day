$('w').onfocus=function(){
	if($('w').value=='请输入关键字'){
		$('w').value='';
		$('w').style.color='#FF0000';
	}	
}
$('w').onblur=function(){
	if($('w').value==''){
		$('w').value='请输入关键字';
		$('w').style.color='#888';
	}	
}
if($('w').value=='请输入关键字' || $('w').value==''){
	$('w').value='请输入关键字';
	$('w').style.color='#888';
}